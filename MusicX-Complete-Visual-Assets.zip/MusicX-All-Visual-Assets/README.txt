MusicX complete visual asset pack

Contains 10 Xcode .imageset folders:

Category cards:
- category_chinese_pop
- category_classic
- category_light (UPDATED: lake + grand piano artwork)
- category_instrumental
- category_rock
- category_singers

Discovery banners:
- daily_recommend
- chart_hot
- chart_new
- chart_rising

All images are 1280x720 JPG with matching Contents.json manifests.
No app code is included in this ZIP.

Import: copy all ten .imageset folders into MusicX/Assets.xcassets/.
If using the repository's import workflow, upload this ZIP to the exact path
configured by that workflow before triggering it.
