MusicX — 10 standalone visual assets

Contains 10 independent high-resolution JPEG assets, each in its own .imageset folder with Contents.json:
- category_chinese_pop
- category_classic
- category_instrumental
- category_light
- category_rock
- category_singers
- chart_hot
- chart_new
- chart_rising
- daily_recommend

No contact sheet or composite collage is used as an app asset. Images are landscape 16:9-style artwork; crop with aspect-fill in the app without stretching.
