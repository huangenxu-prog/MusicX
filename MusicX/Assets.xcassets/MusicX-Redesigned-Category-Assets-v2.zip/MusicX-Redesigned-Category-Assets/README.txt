MusicX redesigned category artwork
Six original 16:9 category images, exported at 1280x720 JPEG.
Copy the six .imageset folders into MusicX/Assets.xcassets/.
Asset names:
- category_chinese_pop
- category_classic
- category_light
- category_instrumental
- category_rock
- category_singers
