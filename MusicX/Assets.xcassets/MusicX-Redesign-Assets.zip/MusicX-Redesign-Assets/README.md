# MusicX Redesign Asset Pack

本包包含统一深蓝渐变视觉方向所需的图片素材，供 MusicX iOS 工程导入。

## 目录
- `Assets.xcassets/`：可直接复制到工程 `MusicX/Assets.xcassets/` 的 imageset。
- `Artwork-Source/`：16 张独立原始主题图，便于后续替换和扩展。

## 已生成的 imageset
首页：`daily_recommend`、`featured_playlist`、`chart_hot`、`chart_rising`、`chart_new`
专辑：`album_01` 至 `album_05`
歌曲封面：`song_01` 至 `song_06`
搜索分类：`SearchCategory01` 至 `SearchCategory06`

## 替换注意
1. 先将本包内 imageset 与工程现有资源名逐一核对。
2. 只有在代码引用已迁移或确认兼容后，才删除旧 imageset。
3. 保留 AppIcon、播放状态图标及其他功能性资源。
4. 本包只包含图片资源和 Contents.json，不包含 SwiftUI 页面代码，也不会修改播放、搜索、收藏等业务逻辑。
5. 搜索歌手头像、歌曲实时封面仍应优先使用音源返回的数据；本包中的主题图仅作为展示素材和无封面时的视觉资源。
