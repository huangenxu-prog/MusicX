MusicX 封面资源替换包

目录结构：
MusicX/Assets.xcassets/

包含 11 个可直接放入 Xcode Assets.xcassets 的 imageset：

专辑封面：
- album_01：DUO（陈奕迅）
- album_02：最伟大的作品（周杰伦）
- album_03：宇宙的有趣（告五人）
- album_04：LINK（A-Lin）
- album_05：幼鸟指南（毛不易）

精选歌单封面：
- playlist_weekly：本周编辑精选
- playlist_mandopop：华语流行精选
- playlist_classics：经典金曲精选
- playlist_indie：独立音乐精选
- playlist_ost：影视原声精选
- playlist_commute：通勤驾驶精选

上传方式：
将压缩包内 MusicX/Assets.xcassets/ 下的 11 个 .imageset 文件夹，复制到仓库对应的 MusicX/Assets.xcassets/ 目录。
如果系统询问是否替换同名文件夹，选择替换/覆盖。
不要删除 Assets.xcassets 中其他资源。

本包只包含 PNG 和对应的 Xcode Contents.json；未包含原始 SVG、预览拼图或其他项目文件。
