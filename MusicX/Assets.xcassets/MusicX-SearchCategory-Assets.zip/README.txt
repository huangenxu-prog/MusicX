MusicX 搜索页分类卡片素材包

目录结构：
MusicX/Assets.xcassets/SearchCategory01.imageset/Contents.json + SearchCategory01.jpg
...共六套。

导入方式：将六个 SearchCategoryXX.imageset 文件夹复制到项目的
MusicX/Assets.xcassets/ 目录中；若同名目录已存在，请先备份，再整体替换。

SwiftUI 资源名：SearchCategory01 ... SearchCategory06（不带扩展名）。
图片为 240x135 JPG，16:9，无文字背景图；卡片标题/副标题由 SwiftUI 叠加。
