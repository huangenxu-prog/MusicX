MusicX 首页视觉素材包

将这些 *.imageset 文件夹复制到工程现有的 MusicX/Assets.xcassets/ 目录中（不要覆盖整个 Assets.xcassets）。
资源名与 SwiftUI Image(name) 对应；文件尺寸见 manifest.json。
注意：素材来自统一生成的 5×5 原始图像网格裁切，输出文件已按页面规格缩放；可用于当前界面开发预览。
